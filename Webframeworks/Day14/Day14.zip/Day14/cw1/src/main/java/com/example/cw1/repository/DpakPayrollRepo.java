package com.example.cw1.repository;

import com.example.cw1.model.DpakPayroll;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DpakPayrollRepo extends JpaRepository<DpakPayroll,Long>{
    
}
