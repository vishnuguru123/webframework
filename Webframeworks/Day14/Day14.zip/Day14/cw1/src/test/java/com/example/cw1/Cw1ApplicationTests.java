package com.example.cw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
