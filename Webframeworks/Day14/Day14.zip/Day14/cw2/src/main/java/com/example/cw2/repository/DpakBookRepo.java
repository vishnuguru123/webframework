package com.example.cw2.repository;
import com.example.cw2.model.DpakBook;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DpakBookRepo extends JpaRepository<DpakBook, Long> {
}

